int main() {
	/** this is a 

	test

	**/
	int a = 10, b = 20;
	if (a >= b) {
		double c = 10;
	}
	else {
		float d = .123 + 40.56;
		b--;
		a ++ ;
	}
	// finished!
}